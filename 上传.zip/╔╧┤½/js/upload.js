			var wb;//读取完成的数据
            var rABS = false; //是否将文件读取为二进制字符串

            function importf(obj) {//导入
                if(!obj.files) {
                    return;
                }
                var f = obj.files[0];
                var reader = new FileReader();
                reader.onload = function(e) {
                    var data = e.target.result;
                    if(rABS) {
                        wb = XLSX.read(btoa(fixdata(data)), {//手动转化
                            type: 'base64'
                        });
                    } else {
                        wb = XLSX.read(data, {
                            type: 'binary'
                        });
                    }
					
					//解析到的数据
					var list =  XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]);
					console.log(list)
// 					console.log(list[0])
// 					console.log(list[0].姓名)
// 					var list = JSON.stringify( XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]]) );
// 					console.log(list)


					//表格渲染
					var tab = document.getElementById('tab');
					for(var i=0; i<list.length; i++){
						var tr = document.createElement('tr');
						var td1 = document.createElement('td');
						var td2 = document.createElement('td');
						td1.innerHTML = list[i].__rowNum__;
						td2.innerHTML = list[i].姓名;
						tr.appendChild(td1);
						tr.appendChild(td2);
						tab.appendChild(tr);
					}
					 




				};
                if(rABS) {
                    reader.readAsArrayBuffer(f);
                } else {
                    reader.readAsBinaryString(f);
                }
            }


//             function fixdata(data) { //文件流转BinaryString
//                 var o = "",
//                     l = 0,
//                     w = 10240;
//                 for(; l < data.byteLength / w; ++l) o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w, l * w + w)));
//                 o += String.fromCharCode.apply(null, new Uint8Array(data.slice(l * w)));
//                 return o;
//             }


		
		
	
		
